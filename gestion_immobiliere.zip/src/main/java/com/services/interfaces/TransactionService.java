package com.services.interfaces;

import java.util.List;

import com.bo.Transaction;
import com.boudaa.dao.exceptions.EntityNotFoundException;

public interface TransactionService{
	
		//Ajouter une commande dans la base de donn�es:
		void saveTransaction(Transaction pTransaction);
		
		// retour de toutes les commandes: 
		List<Transaction> getAll();
		
		//Recherche multi-criters d'une commande:
		List<Transaction> findTransaction(Transaction Tr);
		
		//Recherche par idCommande seulement:
		Transaction findTransactionById(int tId) throws EntityNotFoundException;
		
}
