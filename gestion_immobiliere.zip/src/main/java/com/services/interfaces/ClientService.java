package com.services.interfaces;

import java.util.List;

import com.bo.Client;
import com.boudaa.dao.exceptions.EntityNotFoundException;

public interface ClientService {
	
	//Sauvgarder un client dans la base de donn�es:
	void saveClient(Client client);

	//affichage de tous les clients de la base de donn�es:
	List<Client> getAll();

	//Recherche multi-crit�res d'un client: 
	List<Client> findClient(Client c);

	// recherche du client par Id: 
	Client findClientById(int cId) throws EntityNotFoundException;

}
