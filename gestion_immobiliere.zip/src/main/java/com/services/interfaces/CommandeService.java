package com.services.interfaces;

import java.util.List;

import com.bo.Commande;
import com.boudaa.dao.exceptions.EntityNotFoundException;

public interface CommandeService {

		//Ajouter une commande dans la base de donn�es:
		void saveCommande(Commande commande);

		// retour de toutes les commandes: 
		List<Commande> getAll();

		//Recherche multi-criters d'une commande:
		List<Commande> findCommande(Commande co);

		//Recherche par idCommande seulement:
		Commande findCommandeById(int cId) throws EntityNotFoundException;

}
