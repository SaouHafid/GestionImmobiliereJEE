package com.services.interfaces;

import java.util.List;

import com.bo.Bien;
import com.boudaa.dao.exceptions.EntityNotFoundException;

public interface BienService {

	//Sauvegarder un Bien dans la base de donn�es:
	void saveBien(Bien bien);

	//affichage de tous les Biens de la base de donn�es:
	List<Bien> getAll();

	//Recherche multi-critetre d'un Bien:
	List<Bien> findBien(Bien b);

	//recherche par Id seulement:
	Bien findBienById(int bId) throws EntityNotFoundException;
}
