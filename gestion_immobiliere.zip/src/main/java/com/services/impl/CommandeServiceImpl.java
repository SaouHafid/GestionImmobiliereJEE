package com.services.impl;

import java.util.ArrayList;
import java.util.List;

import com.bo.Commande;
import com.boudaa.dao.exceptions.EntityNotFoundException;
import com.dao.interfaces.BienDao;
import com.dao.interfaces.ClientDao;
import com.dao.interfaces.CommandeDao;
import com.dao.interfaces.TransactionDao;
import com.services.interfaces.CommandeService;

public class CommandeServiceImpl implements CommandeService {

	private ClientDao clientDao;
	private BienDao bienDao;
	private CommandeDao commandeDao;
	private TransactionDao transactionDao;
	
	//Les m�thodes implement�es depuis l'interface CommandeService :
	//Ajouter une commande dans la base de donn�es:
		/* (non-Javadoc)
		 * @see com.services.impl.CommandeService#saveCommande(com.bo.Commande)
		 */
		@Override
		public void saveCommande(Commande commande){
			commandeDao.create(commande);
		}
		
		// retour de toutes les commandes: 
		/* (non-Javadoc)
		 * @see com.services.impl.CommandeService#getAll()
		 */
		@Override
		public List<Commande> getAll(){
			return commandeDao.getAll();
		}
		
		//Recherche multi-criters d'une commande:
		/* (non-Javadoc)
		 * @see com.services.impl.CommandeService#findClient(com.bo.Commande)
		 */
		@Override
		public List<Commande> findCommande(Commande co){
			
			if(co.getIdCommande() != 0 ){
				return commandeDao.getEntityByColumn("Commande", "idCommande", String.valueOf(co.getIdCommande()));
			}
			else if(co.getLibelle() != null && !co.getLibelle().isEmpty()){
				return commandeDao.getEntityByColumn("Commande", "libelle", co.getLibelle());
			}
			
			return new ArrayList<Commande>();
		}
		
		//Recherche par idCommande seulement:
		/* (non-Javadoc)
		 * @see com.services.impl.CommandeService#findClientById(int)
		 */
		@Override
		public Commande findCommandeById(int cId) throws EntityNotFoundException{
			return commandeDao.findById(cId);
		}
		
	//Getters Et Setters :
	public ClientDao getClientDao() {
		return clientDao;
	}
	public void setClientDao(ClientDao clientDao) {
		this.clientDao = clientDao;
	}
	public BienDao getBienDao() {
		return bienDao;
	}
	public void setBienDao(BienDao bienDao) {
		this.bienDao = bienDao;
	}
	public CommandeDao getCommandeDao() {
		return commandeDao;
	}
	public void setCommandeDao(CommandeDao commandeDao) {
		this.commandeDao = commandeDao;
	}
	public TransactionDao getTransactionDao() {
		return transactionDao;
	}
	public void setTransactionDao(TransactionDao transactionDao) {
		this.transactionDao = transactionDao;
	}
	
	
}
