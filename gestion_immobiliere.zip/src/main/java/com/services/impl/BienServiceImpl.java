package com.services.impl;

import java.util.ArrayList;
import java.util.List;

import com.bo.Bien;
import com.boudaa.dao.exceptions.EntityNotFoundException;
import com.dao.interfaces.BienDao;
import com.dao.interfaces.ClientDao;
import com.dao.interfaces.CommandeDao;
import com.dao.interfaces.TransactionDao;

import com.services.interfaces.BienService;

public class BienServiceImpl implements BienService {

	private ClientDao clientDao;
	private BienDao bienDao;
	private CommandeDao commandeDao;
	private TransactionDao transactionDao;
	
	//Sauvegarder un Bien dans la base de donn�es:
		/* (non-Javadoc)
		 * @see com.services.impl.BienService#saveBien(com.bo.Bien)
		 */
		@Override
		public void saveBien(Bien bien){
			bienDao.create(bien);
		}
		
		//affichage de tous les Biens de la base de donn�es:
		/* (non-Javadoc)
		 * @see com.services.impl.BienService#getAll()
		 */
		@Override
		public List<Bien> getAll(){
			return bienDao.getAll();
		}
		
		//Recherche multi-critetre d'un Bien:
		/* (non-Javadoc)
		 * @see com.services.impl.BienService#findClient(com.bo.Bien)
		 */
		@Override
		public List<Bien> findBien(Bien b){
			
			if(b.getAdresse() != null && !b.getAdresse().isEmpty()){
				return bienDao.getEntityByColumn("Bien", "adresse", b.getAdresse());
			}
			else if(b.getSurface() != 0){
				return bienDao.getEntityByColumn("Bien", "surface", String.valueOf(b.getSurface()));
			}
			else if(b.getDateAjout() != null ){
				return bienDao.getEntityByColumn("Bien", "dateAjout", String.valueOf(b.getDateAjout()));
			}
			
			return new ArrayList<Bien>();
			
		}
		
		//recherche par Id seulement:
		/* (non-Javadoc)
		 * @see com.services.impl.BienService#findClientById(int)
		 */
		@Override
		public Bien findBienById(int bId) throws EntityNotFoundException{
			return bienDao.findById(bId);
		}
		
	//Getters et Setters:
	public ClientDao getClientDao() {
		return clientDao;
	}
	public void setClientDao(ClientDao clientDao) {
		this.clientDao = clientDao;
	}
	public BienDao getBienDao() {
		return bienDao;
	}
	public void setBienDao(BienDao bienDao) {
		this.bienDao = bienDao;
	}
	public CommandeDao getCommandeDao() {
		return commandeDao;
	}
	public void setCommandeDao(CommandeDao commandeDao) {
		this.commandeDao = commandeDao;
	}
	public TransactionDao getTransactionDao() {
		return transactionDao;
	}
	public void setTransactionDao(TransactionDao transactionDao) {
		this.transactionDao = transactionDao;
	}
	
	
	
}
