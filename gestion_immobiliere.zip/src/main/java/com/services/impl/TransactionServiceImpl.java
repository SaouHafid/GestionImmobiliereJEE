package com.services.impl;

import java.util.ArrayList;
import java.util.List;

import com.bo.Transaction;
import com.boudaa.dao.exceptions.EntityNotFoundException;
import com.dao.interfaces.BienDao;
import com.dao.interfaces.ClientDao;
import com.dao.interfaces.CommandeDao;
import com.dao.interfaces.TransactionDao;
import com.services.interfaces.TransactionService;
 
public class TransactionServiceImpl implements TransactionService{

	private ClientDao clientDao;
	private BienDao bienDao;
	private CommandeDao commandeDao;
	private TransactionDao transactionDao;
	
	//Les methodes implementees depuis l'interface:
	@Override
	public void saveTransaction(Transaction pTransaction) {
		transactionDao.create(pTransaction);
	}

	@Override
	public List<Transaction> getAll() {
		
		return transactionDao.getAll();
		
	}

	@Override
	public List<Transaction> findTransaction(Transaction Tr) {
		
		if(Tr.getIdTrans() != 0 ){
			return transactionDao.getEntityByColumn("Transaction", "IdTrans", String.valueOf(Tr.getIdTrans()));
		}
		else if(Tr.getLibelle() != null && !Tr.getLibelle().isEmpty()){
			return transactionDao.getEntityByColumn("Transaction", "libelle", Tr.getLibelle());
		}
		return new ArrayList<Transaction>();
	}

	@Override
	public Transaction findTransactionById(int tId) throws EntityNotFoundException {
		
		return transactionDao.findById(tId);
		
	}
	
		//Getters et Setters:
		public ClientDao getClientDao() {
			return clientDao;
		}

		public void setClientDao(ClientDao clientDao) {
			this.clientDao = clientDao;
		}

		public BienDao getBienDao() {
			return bienDao;
		}

		public void setBienDao(BienDao bienDao) {
			this.bienDao = bienDao;
		}

		public CommandeDao getCommandeDao() {
			return commandeDao;
		}

		public void setCommandeDao(CommandeDao commandeDao) {
			this.commandeDao = commandeDao;
		}

		public TransactionDao getTransactionDao() {
			return transactionDao;
		}

		public void setTransactionDao(TransactionDao transactionDao) {
			this.transactionDao = transactionDao;
		}


}