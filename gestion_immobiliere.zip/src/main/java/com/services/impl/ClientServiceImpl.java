package com.services.impl;

import java.util.ArrayList;
import java.util.List;

import com.bo.Client;
import com.boudaa.dao.exceptions.EntityNotFoundException;
import com.dao.interfaces.BienDao;
import com.dao.interfaces.ClientDao;
import com.dao.interfaces.CommandeDao;
import com.dao.interfaces.TransactionDao;
import com.services.interfaces.ClientService;

public class ClientServiceImpl implements ClientService{

	private ClientDao clientDao;
	private BienDao bienDao;
	private CommandeDao commandeDao;
	private TransactionDao transactionDao;
	
	//Les m�thodes impl�ment�es depuis l'interface.
	
	/* (non-Javadoc)
	 * @see com.services.impl.ClientService#saveClient(com.bo.Client)
	 */
	//Sauvgarder un client dans la base de donn�es:
	@Override
	public void saveClient(Client client){
		clientDao.create(client);
	}
	
	//affichage de tous les clients de la base de donn�es:
	/* (non-Javadoc)
	 * @see com.services.impl.ClientService#getAll()
	 */
	@Override
	public List<Client> getAll(){
		return clientDao.getAll();
	}
	
	//Recherche multi-crit�res d'un client: 
	/* (non-Javadoc)
	 * @see com.services.impl.ClientService#findClient(com.bo.Client)
	 */
	@Override
	public List<Client> findClient(Client c){
		
		if(c.getLogin() != null && !c.getLogin().isEmpty()){
			return clientDao.getEntityByColumn("Client", "login", c.getLogin());
		}
		else if(c.getNom() != null && !c.getNom().isEmpty()){
			return clientDao.getEntityByColumn("Client", "nom", c.getNom());
		}
		if(c.getEmail() == null && !c.getEmail().isEmpty()){
			return clientDao.getEntityByColumn("Client", "email", c.getEmail());
		}
		if(c.getAdresse() == null && !c.getAdresse().isEmpty()){
			return clientDao.getEntityByColumn("Client", "adresse", c.getAdresse());
		}
	
		return new ArrayList<Client>();
	}
	// recherche du client par Id: 
	/* (non-Javadoc)
	 * @see com.services.impl.ClientService#findClientById(int)
	 */
	@Override
	public Client findClientById(int cId) throws EntityNotFoundException{
		return clientDao.findById(cId);
	}
	
	
	//Getters et Setters:
	public ClientDao getClientDao() {
		return clientDao;
	}
	public void setClientDao(ClientDao clientDao) {
		this.clientDao = clientDao;
	}
	public BienDao getBienDao() {
		return bienDao;
	}
	public void setBienDao(BienDao bienDao) {
		this.bienDao = bienDao;
	}
	public CommandeDao getCommandeDao() {
		return commandeDao;
	}
	public void setCommandeDao(CommandeDao commandeDao) {
		this.commandeDao = commandeDao;
	}
	public TransactionDao getTransactionDao() {
		return transactionDao;
	}
	public void setTransactionDao(TransactionDao transactionDao) {
		this.transactionDao = transactionDao;
	}
	
}
