package com.bo;

public class Client {

	private int idCl;
	private String nom;
	private String adresse;
	private int tel;
	private String email; 
	private String login;
	private String mdp;
	
	public Client(){
		
	}
	
	public Client(int idCl, String nom, String adresse, int tel, String email, String login, String mdp) {
		super();
		this.idCl = idCl;
		this.nom = nom;
		this.adresse = adresse;
		this.tel = tel;
		this.email = email;
		this.login = login;
		this.mdp = mdp;
	}
	public int getIdCl() {
		return idCl;
	}
	public void setIdCl(int idCl) {
		this.idCl = idCl;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public int getTel() {
		return tel;
	}
	public void setTel(int tel) {
		this.tel = tel;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getMdp() {
		return mdp;
	}
	public void setMdp(String mdp) {
		this.mdp = mdp;
	}
	
	
}
