package com.bo;

public class Commande {

	private int idCommande;
	private String libelle;
	
	public Commande(){
		
	}
	
	public Commande(int idCommande, String libelle) {
		super();
		this.idCommande = idCommande;
		this.libelle = libelle;
	}

	public int getIdCommande() {
		return idCommande;
	}
	public void setIdCommande(int idCommande) {
		this.idCommande = idCommande;
	}
	public String getLibelle() {
		return libelle;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	
	
}
