package com.bo;

public class Transaction {

	private int idTrans;
	private String libelle;
	
	public Transaction(){
		
	}
	
	public Transaction(int idTrans, String libelle) {
		super();
		this.idTrans = idTrans;
		this.libelle = libelle;
	}
	
	public int getIdTrans() {
		return idTrans;
	}
	public void setIdTrans(int idTrans) {
		this.idTrans = idTrans;
	}
	public String getLibelle() {
		return libelle;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	
}
