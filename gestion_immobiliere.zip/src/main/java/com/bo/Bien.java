package com.bo;

import java.util.Date;

public class Bien {
	
	private int idBien;
	private double prix;
	private Date dateAjout;
	private double surface;
	private String adresse;
	private int nbChambre;
	private int nbGarage;
	private int nbEtage;
	private int nbBalcon;
	private boolean Disponible;
	
	public Bien(){
		
	}
	public Bien(int idBien, double prix, Date dateAjout, double surface, String adresse, int nbChambre, int nbGarage,
			int nbEtage, int nbBalcon, boolean disponible) {
		super();
		this.idBien = idBien;
		this.prix = prix;
		this.dateAjout = dateAjout;
		this.surface = surface;
		this.adresse = adresse;
		this.nbChambre = nbChambre;
		this.nbGarage = nbGarage;
		this.nbEtage = nbEtage;
		this.nbBalcon = nbBalcon;
		Disponible = disponible;
	}
	//Getters & Setters:
	public int getIdBien() {
		return idBien;
	}
	public void setIdBien(int idBien) {
		this.idBien = idBien;
	}
	public double getPrix() {
		return prix;
	}
	public void setPrix(double prix) {
		this.prix = prix;
	}
	public Date getDateAjout() {
		return dateAjout;
	}
	public void setDateAjout(Date dateAjout) {
		this.dateAjout = dateAjout;
	}
	public double getSurface() {
		return surface;
	}
	public void setSurface(double surface) {
		this.surface = surface;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public int getNbChambre() {
		return nbChambre;
	}
	public void setNbChambre(int nbChambre) {
		this.nbChambre = nbChambre;
	}
	public int getNbGarage() {
		return nbGarage;
	}
	public void setNbGarage(int nbGarage) {
		this.nbGarage = nbGarage;
	}
	public int getNbEtage() {
		return nbEtage;
	}
	public void setNbEtage(int nbEtage) {
		this.nbEtage = nbEtage;
	}
	public int getNbBalcon() {
		return nbBalcon;
	}
	public void setNbBalcon(int nbBalcon) {
		this.nbBalcon = nbBalcon;
	}
	public boolean isDisponible() {
		return Disponible;
	}
	public void setDisponible(boolean disponible) {
		Disponible = disponible;
	}
	
}
