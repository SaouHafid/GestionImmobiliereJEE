package com.dao.interfaces;

import com.bo.Transaction;
import com.boudaa.dao.GenericDao;

public interface TransactionDao extends GenericDao<Transaction, Integer>{

}
