package com.dao.interfaces;

import com.bo.Commande;
import com.boudaa.dao.GenericDao;

public interface CommandeDao extends GenericDao<Commande, Integer>{

}
