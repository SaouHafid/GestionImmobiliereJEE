package com.dao.interfaces;

import com.bo.Client;
import com.boudaa.dao.GenericDao;

public interface ClientDao extends GenericDao<Client, Integer>{

}
