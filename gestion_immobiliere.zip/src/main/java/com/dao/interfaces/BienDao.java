package com.dao.interfaces;

import com.bo.Bien;
import com.boudaa.dao.GenericDao;

public interface BienDao extends GenericDao<Bien, Integer>{

}
