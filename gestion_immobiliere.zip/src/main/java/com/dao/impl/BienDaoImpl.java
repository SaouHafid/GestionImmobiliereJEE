package com.dao.impl;

import com.bo.Bien;
import com.boudaa.dao.impl.GenericDaoImpl;
import com.dao.interfaces.BienDao;

public class BienDaoImpl extends GenericDaoImpl<Bien, Integer> implements BienDao{

	public BienDaoImpl() {
		
		super(Bien.class);
	}

}
