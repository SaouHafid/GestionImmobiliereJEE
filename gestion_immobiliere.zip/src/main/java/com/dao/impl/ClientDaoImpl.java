package com.dao.impl;

import com.bo.Client;
import com.boudaa.dao.impl.GenericDaoImpl;
import com.dao.interfaces.ClientDao;

public class ClientDaoImpl extends GenericDaoImpl<Client, Integer> implements ClientDao{

	public ClientDaoImpl() {
		
		super(Client.class);
		
	}

}
