package com.dao.impl;

import com.bo.Transaction;
import com.boudaa.dao.impl.GenericDaoImpl;
import com.dao.interfaces.TransactionDao;

public class TransactionDaoImpl extends GenericDaoImpl<Transaction, Integer> implements TransactionDao{
	
	public TransactionDaoImpl() {
		
		super(Transaction.class);
	}
	

}
