package com.dao.impl;

import com.bo.Commande;
import com.boudaa.dao.impl.GenericDaoImpl;
import com.dao.interfaces.CommandeDao;

public class CommandeDaoImpl extends GenericDaoImpl<Commande, Integer> implements CommandeDao{

	public CommandeDaoImpl() {
	
		super(Commande.class);
	}
}
