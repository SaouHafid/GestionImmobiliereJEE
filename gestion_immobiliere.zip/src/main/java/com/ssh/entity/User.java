package com.ssh.entity;
 
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;
 
@Entity
@Table(name = "users")
public class User implements Serializable {
 
    private Long id;
    private String username, password;
    private Boolean enabled;
    private List<Role> roles = new ArrayList<Role>();
 
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinTable(name = "user_roles", joinColumns = {
        @JoinColumn(name = "userId"),}, inverseJoinColumns = {
        @JoinColumn(name = "roleId")})
    public List<Role> getRoles() {
        return roles;
    }
 
    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }
 
    public Boolean getEnabled() {
        return enabled;
    }
 
    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }
 
    public void setId(Long id) {
        this.id = id;
    }
 
    @Id
    @GeneratedValue
    @Column(name = "userId")
    public Long getId() {
        return id;
    }
 
    public String getPassword() {
        return password;
    }
 
    public void setPassword(String password) {
        this.password = password;
    }
 
    public String getUsername() {
        return username;
    }
 
    public void setUsername(String username) {
        this.username = username;
    }
}