package com.ssh.dao;
 
import com.ssh.entity.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
 
public class UserDao {
 
    SessionFactory sessionFactory = null;
    Session session = null;
 
    public User findUser(String username) throws Exception {
        try {
            sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();
            session = sessionFactory.openSession();
            User user = (User) session.createQuery("from User where username=:username").setParameter("username", username).uniqueResult();
            return user;
        } catch (Exception e) {
            throw new Exception(e);
        } finally {
            session.flush();
            session.close();
        }
    }
}