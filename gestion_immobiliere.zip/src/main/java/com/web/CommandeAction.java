package com.web;

import java.util.List;

import com.bo.Commande;
import com.services.interfaces.CommandeService;

public class CommandeAction extends BaseAction{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<Commande> listCommandes;
	private Commande commande;
	private CommandeService commandeService;
	
	

		//Methode d'initialisation du formulaire "Commande"
		public String initFormCommande(){
			return SUCCESS;
		}
		
		//Initialisation du variable listCommandes (par les commandes contenus dans la DB):
		public String listCommandes(){
				
			listCommandes = commandeService.getAll();
				
			return SUCCESS; 
		}
		
		//Action d'ajout d'une Commande � la DB : 
		public String addCommande(){
				
			commandeService.saveCommande(commande);
		
		return SUCCESS; 
		}
		
		
	//Getters et Setters:
	public List<Commande> getListCommandes() {
		return listCommandes;
	}
	public void setListCommandes(List<Commande> listCommandes) {
		this.listCommandes = listCommandes;
	}
	
	
	public Commande getCommande() {
		return commande; 
	}

	public void setCommande(Commande commande) {
		this.commande = commande;
	}

	public CommandeService getCommandeService() {
		return commandeService;
	}
	public void setCommandeService(CommandeService commandeService) {
		this.commandeService = commandeService;
	}
	
	
}
