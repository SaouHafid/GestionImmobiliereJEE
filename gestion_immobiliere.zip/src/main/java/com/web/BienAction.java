package com.web;

import java.util.ArrayList;
import java.util.List;

import com.bo.Bien;
import com.boudaa.dao.exceptions.EntityNotFoundException;
import com.services.interfaces.BienService;

public class BienAction extends BaseAction {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private BienService bienService;
	private int selectedCategorie;
	private List<Bien> listBiens;
	private Bien bien;
	private int sarchedBien;
	
	
	public BienAction(){
		
	}

	public BienAction(BienService bienService, int selectedCategorie, List<Bien> listBiens, Bien bien,
			int sarchedBien) {
		super();
		this.bienService = bienService;
		this.selectedCategorie = selectedCategorie;
		this.listBiens = listBiens;
		this.bien = bien;
		this.sarchedBien = sarchedBien;
	}



	//Initialisation du formulaire d'ajout d'un Bien:
	public String initFormBien(){  
		
		return SUCCESS;
	}
	
	//Initialisation du variable listBiens (par les biens contenus dans la DB):
	public String listBiens(){
		
		listBiens = bienService.getAll();
		
		return SUCCESS; 
	}
	
	//Action d'ajout d'un bien 
	public String addBien(){
		System.out.println(bien);
		bienService.saveBien(bien);
		return SUCCESS;  
	}
	//Action de recherche d'un bien par son Id: 
	public String searchBien() throws EntityNotFoundException {
		
		//TRACER.error("d�but de la m�thode searchBien avec searchBien=" + searchBien);

		bien = bienService.findBienById(sarchedBien);
		/*if(bien != null){
			listBiens = new ArrayList<>();
			listBiens.add(bien);
		}*/
		
		return SUCCESS; 

	}
	//Getters et Setters:
	
	public BienAction(int sarchedBien) {
		super();
		this.sarchedBien = sarchedBien;
	}

	public int getSarchedBien() {
		return sarchedBien;
	}

	public void setSarchedBien(int sarchedBien) {
		this.sarchedBien = sarchedBien;
	}

	public List<Bien> getListBiens() {
		return listBiens;
	}

	public void setListBiens(List<Bien> listBiens) {
		this.listBiens = listBiens;
	}

	public int getSelectedCategorie() {
		return selectedCategorie;
	}

	public void setSelectedCategorie(int selectedCategorie) {
		this.selectedCategorie = selectedCategorie;
	}
	public BienService getBienService() {
		return bienService;
	}

	public void setBienService(BienService bienService) {
		this.bienService = bienService;
	}

	public Bien getBien() {
		return bien;
	}

	public void setBien(Bien bien) {
		this.bien = bien;
	}
	
	

}
