package com.web;

import java.util.List;

import com.bo.Transaction;
import com.services.interfaces.TransactionService;

public class TransactionAction extends BaseAction{
	
	private static final long serialVersionUID = 1L; 
	
	private List<Transaction> listTransactions;
	private Transaction transaction;
	private TransactionService transactionService;
	
	//Methode d'initialisation du formulaire "Transaction"
			public String initFormTransaction(){
				return SUCCESS;
			}
			
			//Initialisation du variable listTransactions (par les Transactions contenus dans la DB):
			public String listTransactions(){
					
				listTransactions = transactionService.getAll();
					
				return SUCCESS; 
			}
			
			//Action d'ajout d'une Transaction � la DB : 
			public String addTransaction(){
					
				transactionService.saveTransaction(transaction);
			
			return SUCCESS; 
			}
	
	//Getters et Setters:
	public List<Transaction> getListTransactions() {
		return listTransactions;
	}
	public void setListTransactions(List<Transaction> listTransactions) {
		this.listTransactions = listTransactions;
	}
	
	
	public Transaction getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

	public TransactionService getTransactionService() {
		return transactionService;
	}
	public void setTransactionService(TransactionService transactionService) {
		this.transactionService = transactionService;
	}

}
