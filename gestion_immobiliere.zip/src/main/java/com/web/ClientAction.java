package com.web;

import java.util.List;

import com.bo.Client;
import com.services.interfaces.ClientService;

public class ClientAction extends BaseAction{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ClientService clientService;
	private List<Client> listClients;
	private Client client;//client au lieu de pClient au cause de conflit au niveau de nom de Getter et Setter
	
	//Methode d'initialisation du formulaire "Client"
	public String initFormClient(){
		return SUCCESS;
	}
	
	//Initialisation du variable listClients (par les clients contenus dans la DB):
	public String listClients(){
			
		listClients = clientService.getAll();
			
		return SUCCESS; 
	}
	
	//Action d'ajout d'un Client � la DB : 
	public String addClient(){
			
		clientService.saveClient(client);
	
	return SUCCESS; 
	}
	
	//Getters et Setters:
	public List<Client> getListClients() {
		return listClients;
	}

	public void setListClients(List<Client> listClients) {
		this.listClients = listClients;
	}

	

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

		public ClientService getClientService() {
			return clientService;
		} 
		public void setClientService(ClientService clientService) {
			this.clientService = clientService;
		}
	
}
